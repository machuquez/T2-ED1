#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ListaDupla.h"


typedef struct {
    int ID;
    char nome[30];
} Pessoa;

//Printa a Lista
void imprime_Pessoa(void* dado) {
    Pessoa* p = (Pessoa*)dado;
    printf("%d %s\n",p->ID, p->nome);
}

void imprime_toda_lista(ListaDupla* ld) {
    if(ld == NULL || ld->li == NULL) {
        //printf("Lista vazia!\n");
        return;
    }
    
    Elem* atual = ld->li;
	//printf("-----------Comeco da Lista----------\n\n");
    while(atual != NULL) {
        imprime_Pessoa(atual->dado);  
        atual = atual->prox;
    }
    	//printf("-----------Fim da Lista----------\n\n");
}

void imprime_vizinhanca_lista(ListaDupla* ld){
    if(ld == NULL || ld->li == NULL) {
        printf("Lista vazia!\n");
        return;
    }
    
    if(ld->lc == NULL) {
        printf("Cursor não definido!\n");
        return;
    }
    
    //printf("-----------Vizinhanca do cursor----------\n\n");
    
    Elem* atual = ld->lc->ant;  // Começa do anterior
    int i = 0;
    
    while(i < 3) {
        if(i == 0) {
            // ANTERIOR
            if(atual != NULL) {
                //printf("ANTERIOR:\n");
                imprime_Pessoa(atual->dado);
                atual = ld->lc;  // vai para o cursor
            } else {
                //printf("ANTERIOR: NULL\n");
                atual = ld->lc;  // vai para o cursor mesmo sem anterior
            }
        }
        else if(i == 1) {
            // CURSOR (sempre existe)
            //printf("CURSOR:\n");
            imprime_Pessoa(atual->dado);
            atual = ld->lc->prox;  // vai para o próximo
        }
        else if(i == 2) {
            // PRÓXIMO
            if(atual != NULL) {
                //printf("PROXIMO:\n");
                imprime_Pessoa(atual->dado);
            } else {
                //printf("PROXIMO: NULL\n");
            }
        }
        
        //printf("\n");
        i++;
    }
    
    //printf("-----------Fim da vizinhanca----------\n\n");
    return;
}

void imprime_cursor(ListaDupla* ld){
    if(ld == NULL || ld->lc == NULL) {
        //printf("Cursor não definido!\n");
        return;
    }
    
    //printf("-----------Elemento do cursor----------\n\n");
    imprime_Pessoa(ld->lc->dado);
    //printf("\n-----------Fim do elemento----------\n\n");
}

void encontraID(ListaDupla *ld, int ID){
    if(ld == NULL || ld->li == NULL || ID==-1) return;

	Elem* no = ld->li;
    while(no != NULL) {
    	Pessoa *pessoa = (Pessoa *)no->dado;
        if(pessoa->ID==ID) {
        //printf("ID encontrado");
            ld->lc=no;
            //printf("Moveu o cursor para o ID encontrado");
            return;
        }
        no = no->prox;
    }
    //printf("ID nao encontrado\n");
    return;
}


void Faz_Funcao(char Funcao, char* nome, int ID, ListaDupla* ld){
	//Cria o tipo de dados pessoa, com os respectivos dados
	Pessoa p;
	p.ID=ID;
	
	strncpy(p.nome, nome, 29);  
    	p.nome[29] = '\0';
	
	strcpy(p.nome,nome);
	//imprime_Pessoa(&p);
	
	
	switch(Funcao){
	case 'I':	//Insere no Inicio
	insere_lista_dupla_inicio(ld, &p, sizeof(p));
	//printf("Inseriu no comeco da Lista\n");
	break;
	
	case 'F':	//Insere no final
	insere_lista_dupla_final(ld, &p,sizeof(p));
	//printf("Inseriu no Final da Lista\n");
	break;
	
	case 'A':	//Insere Antes do cursor
	insere_lista_dupla_ACursor(ld,&p, sizeof(p));
	//printf("Inseriu Antes do cursor\n");
	
	break;
	
	case 'D':	//Insere Depois do cursor
	insere_lista_dupla_DCursor(ld,&p,sizeof(p));
	//printf("Inseriu Depois do cursor\n");
	
	break;
	
	case 'B':	//Busca o cursor atual
	encontraID(ld,ID);
	//printf("Saiu da Funcao de buscar\n");

	break;

	case 'R':	//Remove atual
	remove_atual(ld);
	
	break;
	
	case 'S':	//Move cursor para o início
	cursorcomeco(ld);
	
	break;
	
	case 'E':	//Move cursor para o fim
	cursorfinal(ld);

	break;
	
	case 'N':	//Move cursor para o próximo
	proxNo(ld);

	break;
	
	case 'P':	//Exibe (print) atual (cursor)
	imprime_cursor(ld);
	break;
	
	case 'L':	//Exibe toda Lista
	imprime_toda_lista(ld);
	
	break;

	case 'V':	//Exibe vizinhos (anterior+atual+proximo)
	imprime_vizinhanca_lista(ld);
	break;
	break;
	
	
		}	
}

void sistema_GerenciaSistema(void) {
	//printf("entrou no Gerencia Sistemas\n");
 	ListaDupla* ListaDupla = cria_lista_dupla();
 	char Linha[100];
	//printf("Ainda n entoru no loop\n");
 	while(fgets(Linha,100,stdin)!=NULL){
 		//printf("Entrou no loop\n");
 		int ID=-1;
 		char nome[30]="";
 		char Funcao='X';
 		char comando;
		//printf("Vai tentar ler\n");
 		int n=sscanf(Linha,"%c %d %29s", &comando,&ID,nome);
 		//printf("Consegui ler\n");
 		if(comando!='X'){
 		if(n>0){
 		Funcao=comando;
		Faz_Funcao(Funcao, nome, ID,ListaDupla);
		}
		else{
			//printf("Erro na coleta de dados\n");
		}
		}
		else{
 		break;
 		}
 		}
 		libera_lista_dupla(ListaDupla);
 		//printf("Destruiu a Lista\n");
 		return;
 	}	   

int main(){
    sistema_GerenciaSistema();
    return 0;
}
