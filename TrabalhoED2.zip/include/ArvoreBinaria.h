#ifndef LISTA_DUPLA_H
#define LISTA_DUPLA_H

#define FALSO      0
#define VERDADEIRO 1
#define OK         1
#define ERRO       0


struct NoArvore{
	void dado;
	struct NoArvore *esqueda;
	struct NoArvore *direita;
};

#endif
